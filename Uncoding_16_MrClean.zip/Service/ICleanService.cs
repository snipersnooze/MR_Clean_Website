﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICleanService" in both code and config file together.
[ServiceContract]
public interface ICleanService
{
    [OperationContract]
    void DoWork();

    [OperationContract]
    bool AddUser(string name, string surname, String cellnum, string email, string password, string type, int purchase, char active);

    [OperationContract]
    User GetUser(int id);

    [OperationContract]
    int TtlNumUser();
    [OperationContract]
    int Login(string email, string password);

    [OperationContract]
    int AddProduct(string pname, int pprice, string pdescrip, string ppicURL, char ppromo, char pactive, string category);

    [OperationContract]
    bool EditProduct(int pid, string pname, int pprice, string pdescrip, string ppicURL, char ppromo, char pactive, string category);

    [OperationContract]
    Product getProduct(int id);

    [OperationContract]
    List<Product> getProducts();

    [OperationContract]
    bool DeleteUser(int uid, char active);

    [OperationContract]
    bool DeleteProduct(int pid, char active);

    [OperationContract]
    User isUser(string email);

    [OperationContract]
    List<Product> isOnPromo();

    [OperationContract]
    Product isProductActive(char active);

    [OperationContract]
    int TotalItemsOnHand();

    [OperationContract]
    List<Product> getFilteredCategory(string category);


    [OperationContract]
    bool AddtoCart(int pid, int uid, int qty);

    [OperationContract]
    List<InvoiceLine> getInvoiceLine(int id);

    [OperationContract]
    List<InvoiceLine> getInvoiceLines(int id);

    [OperationContract]
    Invoice getInvoice(int id);

    [OperationContract]
    List<Invoice> getInvoices();

    [OperationContract]
    void updateCart(int pid, int uid, int newAmount);

    [OperationContract]
    decimal TotalCarts();

    [OperationContract]
    decimal TotalProducts();

    [OperationContract]
    int AddInvoice(int uid, DateTime time);

    [OperationContract]
    bool UpdateInvoice(int iid, int total);

    [OperationContract]
    Inventory getInventory(int id);

    [OperationContract]
    bool UpdateInventory(int id, int qty);

    [OperationContract]
    List<Invoice> getUserInvoices(int id);
    [OperationContract]
    bool AddInvLine(int inv,int pid, int price, int qty, int total, string pname);

    [OperationContract]
    int TotalInvLine(int invoiceid);

    [OperationContract]
    bool RemoveCart(int uid, int pid);

    [OperationContract]
    List<Cart> getCarts(int uid);

    [OperationContract]
    int getCartNumbers(int uid);

    [OperationContract]
    bool EditUser(int uid, string email,  string name, string surname, string cellnum);

    [OperationContract]
    bool AddInventory(int pid, int qty);

    [OperationContract]
    // less than quantity function
    Inventory IsNeedStock(int I_id, int qty);

    [OperationContract]
    bool RemoveWholeCart(int uid);

    [OperationContract]
    int RegUsersPerDay(string date);

    [OperationContract]
    bool checkUserExist(string number, string email);
    [OperationContract]
    int TotalSalesCertainDate(string DateOfanalysis);//number of sales(all totals on invoices added
    [OperationContract]
    int TotalSales();//number of sales(all totals on invoices added

    [OperationContract]
    int TotalSalesCertainRange(string DateOfanalysis_start, string DateOfanalysis_end);//number of sales specific motnh

    [OperationContract]
    int TotalSalesCertainMonth(string DateOfanalysis);//number of sales specific motnh

    [OperationContract]
    void UpdateInvemtoryAdd(int pid,int amntToChangeby);//number of sales specific motnh

    [OperationContract]
    int ToatalTax();


    [OperationContract]
    bool UpdatInventory(int id, int qty);

    [OperationContract]
    List<Product> getItemsUnder(int minPrice,int maxPrice);

    [OperationContract]
    int maxProductSold();

    
}
