﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CleanService" in code, svc and config file together.
public class CleanService : ICleanService
{
    public void DoWork()
    {
    }
    DataClassesDataContext db = new DataClassesDataContext();

    public bool AddUser(string name, string surname, String cellnum, string email, string password, string type, int purchase, char active)
    {

        var newUser = new User
        {
            User_Name = name,
            User_Surname = surname,
            User_CellNum = cellnum,
            User_Email = email,
            User_Password = password,
            User_Type = type,
            User_Purchases = purchase,
            User_Active = active,
            User_DateReg = DateTime.Today
        };

        db.Users.InsertOnSubmit(newUser);
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            
            ex.GetBaseException();
            return false;
        }
    }



    public User GetUser(int id)
    {
        var b = (from u in db.Users
                 where u.User_ID.Equals(id)
                 select u).FirstOrDefault();
        return b;

    }

    public int Login(string email, string password)
    {
        var m = (from n in db.Users
                 where n.User_Email == email && n.User_Password == password
                 select n).FirstOrDefault();
        if (m != null)
        {
            return m.User_ID;
        }
        else
            return 0;
    }
    public List<Product> getItemsUnder(int minPrice,int maxPrice)
    {
        var d = new List<Product>();
        dynamic m = (from p in db.Products
                     where p.P_PRICE>=minPrice  &&
                     p.P_PRICE<=maxPrice
                     select p);

        foreach (Product q in m)
        {
            d.Add(q);
        }
        return d;
    }

    public int AddProduct(string pname, int pprice, string pdescrip, string ppicURL, char ppromo, char pactive, string category)
    {
        var newProduct = new Product
        {
            P_NAME = pname,
            P_PRICE = pprice,
            P_DESCRIPTION = pdescrip,
            P_IMAGE_url = ppicURL,
            P_PROMO = ppromo,
            P_Active = pactive,
            P_Category = category
        };

        db.Products.InsertOnSubmit(newProduct);
        try
        {
            db.SubmitChanges();
            return newProduct.PId;
        }
        catch (Exception ex)
        {

            ex.GetBaseException();
            return 0;
        }
    }

    public bool EditProduct(int pid, string pname, int pprice, string pdescrip, string ppicURL, char ppromo, char pactive, string category)
    {
        Product product = db.Products.Single(p => p.PId.Equals(pid));
        product.P_NAME = pname;
        product.P_PRICE = pprice;
        product.P_DESCRIPTION = pdescrip;
        product.P_IMAGE_url = ppicURL;
        product.P_PROMO = ppromo;
        product.P_Active = pactive;
        product.P_Category = category;
        try
        {
            db.SubmitChanges();
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }

    public Product getProduct(int id)
    {
        var a = (from b in db.Products
                 where b.PId.Equals(id)
                 select b).FirstOrDefault();
        return a;
       
    }

    public List<Product> getProducts()
    {
        var d = new List<Product>();
        dynamic m = (from p in db.Products
                     select p);
        foreach(Product q in m)
        {
            d.Add(q);
        }
        return d;
    }
    public int TotalSales()//number of sales(all totals on invoices added
    {
        var u = (from i in db.Invoices
                 select i.I_Total).Sum();
        return (int)u;
    }
    public int TotalSalesCertainDate(string DateOfanalysis)//number of sales specific motnh
    {
        
            var u = (from i in db.Invoices
                     where i.I_Time.Date==Convert.ToDateTime(DateOfanalysis).Date //Certain date
                     select i.I_Total).Count();
            return u;
        
    }
    public int TotalSalesCertainMonth(string DateOfanalysis)//number of sales specific motnh
    {

        var u = (from i in db.Invoices
                 where i.I_Time.Month == Convert.ToDateTime(DateOfanalysis).Month //Certain date
                 select i.I_Total).Count();
        return u;

    }
    public int TotalSalesCertainRange(string DateOfanalysis_start, string DateOfanalysis_end)//number of sales specific motnh
    {

        var u = (from i in db.Invoices
                 where i.I_Time.Date >= Convert.ToDateTime(DateOfanalysis_start).Date&&
                 i.I_Time.Date <= Convert.ToDateTime(DateOfanalysis_end).Date//Certain date
                 select i.I_Total).Count();
        return u;

    }
    public bool DeleteUser(int uid, char active)
    {
        User user = db.Users.Single(p => p.User_ID.Equals(uid));
        user.User_Active = active;

        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }

    } 

    public bool DeleteProduct(int pid, char active)
    {
        Product product = db.Products.Single(p => p.PId.Equals(pid));
        product.P_Active = active;

        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public User isUser(string email)
    {
        var i = (from u in db.Users
                 where u.User_Email.Equals(email)
                 select u);
        return (User)i;
    }

    public List<Product> isOnPromo()
    {
        var prodlist = new List<Product>();

        var i = (from u in db.Products
                 where u.P_PROMO.Equals('Y')
                 select u);

        foreach (Product p in i)
        {

            prodlist.Add(p);
            
        }


        return prodlist;

    }

    public Product isProductActive(char active)
    {
        var i = (from u in db.Products
                 where u.P_Active.Equals(active)
                 select u);
        return (Product)i;
    }

    public List<Product> getFilteredCategory(string category)
    {
        var prodlist = new List<Product>();
        dynamic products = (from u in db.Products
                            where u.P_Active.Equals("A") && u.P_Category.Equals(category)
                            select u);
        foreach (Product p in products)
        {
            prodlist.Add(p);
        }
        return prodlist;
    }

    public bool AddtoCart(int pid, int uid, int qty)
    {
        var prod = getProduct(pid);


        var currentCart = getCarts(uid);

        if (currentCart != null)
        {
            foreach (Cart c in currentCart)
            {
                if (c.PId.Equals(pid))
                {
                    qty += c.P_Quantity;
                    updateCart(pid, uid, qty);
                    return true;
                }
            }
        }
       
        
            var cart = new Cart
            {
                User_ID = uid,
                PId = pid,
                P_Quantity = qty
            };

            db.Carts.InsertOnSubmit(cart);
            try
            {
                db.SubmitChanges();
                return true;
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return false;
            }
        
    }

    public List<InvoiceLine> getInvoiceLine(int id)
    {
        var list = new List<InvoiceLine>();
        dynamic b = (from u in db.InvoiceLines
                 where u.inv_id.Equals(id)
                 select u);
        foreach(InvoiceLine i in b)
        {
            list.Add(i);
        }
        return list;
    }

    public List<InvoiceLine> getInvoiceLines(int id)
    {
        var d = new List<InvoiceLine>();
        dynamic m = (from p in db.InvoiceLines
                     where p.inv_id.Equals(id)
                     select p); 
        foreach (InvoiceLine q in m)
        {
            d.Add(q);
        }
        return d;
    }

    public void updateCart(int pid, int uid, int newAmount)
    {
        Cart cart = db.Carts.Single(p => p.PId.Equals(pid) && p.User_ID.Equals(uid));
        cart.P_Quantity = newAmount;
        try
        {
            db.SubmitChanges();

        }
        catch (Exception e)
        {
            e.GetBaseException();
        }
    }



    public Invoice getInvoice(int id)
    {//get users invoice
        var b = (from u in db.Invoices
                 where u.I_ID.Equals(id)
                 select u).FirstOrDefault();
        return b;
    }


    public List<Invoice> getUserInvoices(int id)
    {
        var d = new List<Invoice>();
        dynamic m = (from p in db.Invoices
                     where p.User_ID==id
                     select p);
        foreach (Invoice q in m)
        {
            d.Add(q);
        }
        return d;
    }

    public List<Invoice> getInvoices()
    {
        var d = new List<Invoice>();
        dynamic m = (from p in db.Invoices
                     select p);
        foreach (Invoice q in m)
        {
            d.Add(q);
        }
        return d;
    }

    public decimal TotalCarts()
    {
        return (from d in db.Carts
                select d.PId).Count();
    }

    public decimal TotalProducts()
    {
        return (from d in db.Products
                select d.PId).Count();
    }

    public int AddInvoice(int uid, DateTime time)
    {
        var inv = new Invoice
        {
            User_ID = uid,
           // I_Total = total,
            I_Time = time
        };
        db.Invoices.InsertOnSubmit(inv);
        try
        {
            db.SubmitChanges();
            return inv.I_ID;
        }
        catch (Exception e)
        {
            e.GetBaseException();
            return 0;
        }
    }

    public bool UpdateInvoice(int iid, int total)
    {
        Invoice inv = db.Invoices.Single(p => p.I_ID.Equals(iid));
        inv.I_Total = total;
        inv.deliveryttl = 100;
        inv.Tax = (int)(total * 0.15);
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public int TotalItemsOnHand()
    {
        return (int)(from i in db.Inventories
                     select i.Quantity).Sum();
    }



    public Inventory getInventory(int id)
    {
        var b = (from u in db.Inventories
                 where u.PId.Equals(id)
                 select u).FirstOrDefault();
        return b;
    }

    public bool AddInventory(int pid, int qty)
    {
        var invent = new Inventory
        {
            PId = pid,
            Quantity = qty
        };
        db.Inventories.InsertOnSubmit(invent);
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            e.GetBaseException();
            return false;
        }
    }

    public bool UpdateInventory(int id, int qty)
    {
        Inventory invent = db.Inventories.Single(p => p.PId.Equals(id));
        invent.Quantity -= qty;
        invent.Sold += qty;
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public bool UpdatInventory(int id, int qty)
    {
        Inventory invent = db.Inventories.Single(p => p.PId.Equals(id));
        invent.Quantity = qty;
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public bool AddInvLine(int inv,int pid, int price, int qty, int total, string pname)
    {
        var invline = new InvoiceLine
        {
            PId = pid,
            P_PRICE = price,
            P_Quantity = qty,
            IL_Total = total,
            P_Name = pname,
            inv_id=inv
        };

        db.InvoiceLines.InsertOnSubmit(invline);
        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            e.GetBaseException();
            return false;
        }
    }

    public int TotalInvLine(int invoiceid)
    {
        return (int)(from d in db.InvoiceLines
                where d.inv_id==invoiceid
                select d.IL_Total).Sum();
    }

    public bool RemoveCart(int uid, int pid)
    {
        var p = (from i in db.Carts
                 where i.User_ID.Equals(uid) && i.PId.Equals(pid)
                 select i).FirstOrDefault();
        try
        {
            db.Carts.DeleteOnSubmit(p);
            db.SubmitChanges();
            return true;
        } catch(Exception e)
        {
            return false;
        }
    }

    public List<Cart> getCarts(int uid)
    {
        var c = new List<Cart>();
        var li = (from i in db.Carts
                      where i.User_ID.Equals(uid)
                      select i);
       // int id = li.User_ID;
       
        if (li != null)
        {
            foreach( Cart i in li)
            {
                c.Add(i);
            }
            return c;
        }
        else
        {
            return null;
        }
    }

    public bool EditUser(int uid, string email,string name, string surname, string cellnum)
    {
        User user = db.Users.Single(p => p.User_ID.Equals(uid));
        user.User_Name = name;
        user.User_Surname = surname;
        user.User_CellNum = cellnum;
        user.User_Email = email;
        
        
 

        try
        {
            db.SubmitChanges();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }

    public Inventory IsNeedStock(int I_id, int qty)
    {
        var b = (from u in db.Inventories
                 where u.Quantity < qty
                 select u);
        return (Inventory)b;
    }

    public bool RemoveWholeCart(int uid)
    {
        var p = (from i in db.Carts
                 where i.User_ID.Equals(uid)
                 select i);
        try
        {
            foreach(Cart d in p)
            {
                db.Carts.DeleteOnSubmit(d);
                db.SubmitChanges();
            }
            return true;

        }
        catch (Exception e)
        {
            return false;
        }
    }
    public bool checkUserExist(string number, string email)
    {
        var m = (from i in db.Users
                 where
         i.User_Email.Equals(email) || i.User_CellNum.Equals(number)
                 select i).FirstOrDefault();
        if (m == null)
        {
            return true;
        }
        else
        {
            return false;

        }
    }
    public int RegUsersPerDay(string date)
    {
        var b = (from u in db.Users
                 where u.User_DateReg== Convert.ToDateTime(date)
                 select u).Count();
        return b;
    }

    public int TtlNumUser()
    {
        var u = (from i in db.Users
                 select i).Count();
        return u;
    }

    public void UpdateInvemtoryAdd(int pid, int amntToChangeby)
    {
        Inventory invent = db.Inventories.Single(p => p.PId.Equals(pid));
        invent.Quantity -=amntToChangeby;

        try
        {
            db.SubmitChanges();
         
        }
        catch (Exception e)
        {
            e.GetBaseException();
        }
    }

    public int ToatalTax()
    {
        var m = (from i in db.Invoices
                 select i.Tax).Sum();
        return (int)m;
    }

   
    public int maxProductSold()
    {
        var i = (from m in db.Inventories select m.Sold).Max();

        var mp = (from m in db.Inventories
                  where m.Sold == i
                  select m.PId).FirstOrDefault();
        return mp;
    }

    public int getCartNumbers(int uid)
    {

        dynamic num = (from i in db.Carts
                      where i.User_ID.Equals(uid)
                      select i).Count();

        return num;
       
    }
}
